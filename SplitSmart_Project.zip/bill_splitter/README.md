# SplitSmart — SmartCommunity Hack (Project #15: Bill Splitter)

A complete, fault-tolerant Python application engineered to split group bills fairly with optional tips, strict input validation, dual JSON/CSV persistence, executive analytics, Matplotlib visual reporting, threshold warnings, bulk CSV imports, and both a **Modern Dark Fintech Streamlit Web GUI** and an **ANSI Terminal CLI**.

## Features Implemented
- **Dual Interfaces**:
  - **Streamlit Web GUI (`app.py`)**: Modern dark fintech dashboard with live split previews, participant builder, KPI metrics, embedded Matplotlib charts, search/filters, settlement toggles, one-click exports, and bulk CSV uploader.
  - **Interactive Terminal CLI (`cli.py`)**: ANSI-formatted menu system, defensive input loops, paginated ASCII tables, and full CRUD/analytics parity.
- **Core Business Logic (`src/engine.py`)**: Equal, Exact Amount, and Percentage splits with proportional tip distribution and fair penny-rounding reconciliation.
- **Defensive Validation (`src/validator.py`)**: Regex date checks, positive numeric bounds, tip range enforcement (0%–100%), duplicate participant prevention, and split-sum verification.
- **Fault-Tolerant Persistence (`src/storage.py`)**: Synchronized `bills.json` and `bills.csv` with automatic corruption backup & recovery.
- **Analytics & Threshold Warnings (`src/analytics.py`)**: Executive KPIs, overdue settlement alerts (>14 days), high-value budget breach flags (>$500), tip anomaly flags, and high-DPI Matplotlib charts.
- **Multi-Format Exports & Bulk Import (`src/exporter.py`, `src/storage.py`)**: Export to Markdown (`.md`), Plain-Text Audit Log (`.txt`), and CSV (`.csv`); bulk ingest legacy CSV files with row-by-row error logs.
- **Pre-Seeded Realistic Dataset (`src/seed.py`)**: 40 realistic test records covering normal bills, boundary conditions, zero-tip/high-tip cases, and overdue balances.

## Quickstart

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Launch Modern Streamlit Web GUI
```bash
streamlit run app.py
```

### 3. Launch Interactive Terminal CLI (Hackathon Demo Mode)
```bash
python cli.py
```

### 4. Run Automated Tests
```bash
pytest -v
```
