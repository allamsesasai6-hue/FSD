from __future__ import annotations
from datetime import datetime
from pathlib import Path
import tempfile
import pandas as pd
import streamlit as st

from src.models import CATEGORIES, SPLIT_MODES
from src.engine import calculate_bill_split
from src.validator import ValidationError
from src.storage import StorageManager
from src.analytics import (
    generate_executive_summary,
    detect_threshold_warnings,
    generate_analytics_charts,
)
from src.exporter import export_all_formats
from src.seed import ensure_seeded

st.set_page_config(
    page_title="SplitSmart | Fintech Bill Splitter",
    page_icon="💳",
    layout="wide",
    initial_sidebar_state="expanded",
)

st.markdown(
    """
    <style>
    .stApp {
        background-color: #0E1117;
        color: #F0F6FC;
    }
    div[data-testid="stMetric"] {
        background: linear-gradient(145deg, #161B22, #1C2331);
        border: 1px solid #30363D;
        padding: 16px 20px;
        border-radius: 12px;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.35);
    }
    div[data-testid="stMetricValue"] {
        color: #00D4AA !important;
        font-weight: 700;
    }
    .fintech-badge {
        display: inline-block;
        padding: 4px 10px;
        border-radius: 999px;
        font-size: 0.78rem;
        font-weight: 600;
        background: rgba(0, 212, 170, 0.14);
        color: #00D4AA;
        border: 1px solid rgba(0, 212, 170, 0.35);
    }
    </style>
    """,
    unsafe_allow_html=True,
)


@st.cache_resource
def get_storage() -> StorageManager:
    sm = StorageManager()
    ensure_seeded(sm)
    return sm


storage = get_storage()
records, recovery_warning = storage.load_all()

with st.sidebar:
    st.markdown("## 💳 SplitSmart")
    st.markdown('<span class="fintech-badge">SmartCommunity Hack #15</span>', unsafe_allow_html=True)
    st.markdown("---")
    page = st.radio(
        "Navigation",
        [
            "📊 Executive Dashboard",
            "➕ Split & Create Bill",
            "📒 Bill Ledger & Search",
            "📈 Analytics & Warnings",
            "📤 Export & Bulk Import",
        ],
    )
    st.markdown("---")
    st.caption(f"Persisted Records: **{len(records)}**")
    st.caption("Storage: `data/bills.json` + `data/bills.csv`")

if recovery_warning:
    st.warning(recovery_warning)

summary = generate_executive_summary(records)
warnings = detect_threshold_warnings(records)

if page == "📊 Executive Dashboard":
    st.title("📊 Executive Financial Dashboard")
    st.caption("Real-time overview of group expenses, tip distributions, and pending collections.")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Total Volume", f"${summary['total_volume']:,.2f}", f"{summary['total_bills']} Bills")
    c2.metric("Average Bill", f"${summary['avg_bill']:,.2f}", f"Avg Tip {summary['avg_tip_pct']:.1f}%")
    c3.metric("Pending Collections", f"${summary['total_pending_amount']:,.2f}", f"{summary['pending_count']} Unsettled")
    c4.metric("Top Category", summary["top_category"], f"{summary['settled_count']} Settled")

    st.markdown("### Visual Expense Intelligence")
    charts = generate_analytics_charts(records, dark_theme=True)
    col_a, col_b = st.columns(2)
    with col_a:
        st.image(str(charts["category_chart"]), use_container_width=True)
    with col_b:
        st.image(str(charts["trend_chart"]), use_container_width=True)

    col_left, col_right = st.columns([1.3, 1])
    with col_left:
        st.markdown("### Recent Transactions")
        recent_rows = [
            {
                "ID": r.id,
                "Date": r.date,
                "Title": r.title,
                "Category": r.category,
                "Total": f"${r.total_amount:,.2f}",
                "Status": "✅ Settled" if r.is_settled else f"⏳ Pending (${r.pending_amount:,.2f})",
            }
            for r in records[:8]
        ]
        st.dataframe(pd.DataFrame(recent_rows), use_container_width=True, hide_index=True)

    with col_right:
        st.markdown("### Top Outstanding Balances")
        if summary["participant_balances"]:
            owed_df = pd.DataFrame(
                [
                    {"Participant": name, "Amount Owed": f"${amt:,.2f}"}
                    for name, amt in list(summary["participant_balances"].items())[:8]
                ]
            )
            st.dataframe(owed_df, use_container_width=True, hide_index=True)
        else:
            st.success("All participant balances are settled!")

elif page == "➕ Split & Create Bill":
    st.title("➕ Split & Record a New Bill")
    st.caption("Defensive validation ensures exact penny reconciliation across Equal, Exact, and Percentage splits.")

    col1, col2 = st.columns(2)
    with col1:
        title = st.text_input("Bill Title *", placeholder="e.g., Friday Team Sushi Dinner")
        category = st.selectbox("Category *", CATEGORIES)
        date_val = st.date_input("Bill Date *", value=datetime.now())
    with col2:
        subtotal = st.number_input("Subtotal Amount ($) *", min_value=0.01, value=120.00, step=5.00)
        tip_percent = st.slider("Optional Tip (%)", min_value=0.0, max_value=100.0, value=15.0, step=1.0)
        split_mode = st.selectbox("Split Mode *", SPLIT_MODES)

    notes = st.text_input("Notes (Optional)", placeholder="Receipt ref, venue, or special split notes")

    st.markdown("### Participants & Share Configuration")
    num_participants = st.number_input("Number of Participants", min_value=1, max_value=30, value=3, step=1)

    default_names = ["Aarav", "Priya", "Rohan", "Ananya", "Vikram", "Sneha"]
    names = []
    values = []
    paid_flags = []

    cols = st.columns(3)
    for i in range(int(num_participants)):
        with cols[i % 3]:
            st.markdown(f"**Person #{i + 1}**")
            default_n = default_names[i] if i < len(default_names) else f"Person {i + 1}"
            p_name = st.text_input("Name", value=default_n, key=f"pname_{i}")
            names.append(p_name)

            if split_mode == "Percentage":
                default_pct = round(100.0 / num_participants, 2)
                val = st.number_input("Share (%)", min_value=0.0, max_value=100.0, value=default_pct, key=f"pval_{i}")
                values.append(val)
            elif split_mode == "Exact":
                default_ex = round(subtotal / num_participants, 2)
                val = st.number_input("Exact Subtotal ($)", min_value=0.0, value=default_ex, key=f"pval_{i}")
                values.append(val)

            paid = st.checkbox("Already Paid", value=(i == 0), key=f"ppaid_{i}")
            paid_flags.append(paid)

    st.markdown("---")
    try:
        preview_bill = calculate_bill_split(
            title=title or "Preview Bill",
            category=category,
            date_str=date_val.strftime("%Y-%m-%d"),
            subtotal=subtotal,
            tip_percent=tip_percent,
            split_mode=split_mode,
            participant_names=names,
            split_values=values if split_mode != "Equal" else None,
            paid_flags=paid_flags,
            notes=notes,
        )
        m1, m2, m3 = st.columns(3)
        m1.metric("Subtotal", f"${preview_bill.subtotal:,.2f}")
        m2.metric(f"Tip ({preview_bill.tip_percent:.0f}%)", f"${preview_bill.tip_amount:,.2f}")
        m3.metric("Grand Total", f"${preview_bill.total_amount:,.2f}")

        breakdown_df = pd.DataFrame(
            [
                {
                    "Participant": p.name,
                    "Subtotal Share": f"${p.subtotal_share:,.2f}",
                    "Tip Share": f"${p.tip_share:,.2f}",
                    "Total Payable": f"${p.total_share:,.2f}",
                    "Status": "Paid" if p.paid else "Pending",
                }
                for p in preview_bill.participants
            ]
        )
        st.dataframe(breakdown_df, use_container_width=True, hide_index=True)

        if st.button("💾 Save Bill to Persistent Storage", type="primary", use_container_width=True):
            if not title.strip():
                st.error("Please enter a valid Bill Title before saving.")
            else:
                storage.add_record(preview_bill)
                st.success(f"Bill **{preview_bill.title}** (`{preview_bill.id}`) saved to JSON & CSV!")
                st.rerun()

    except ValidationError as err:
        st.error(f"Validation Check: {err}")

elif page == "📒 Bill Ledger & Search":
    st.title("📒 Bill Ledger, Search & Settlement Manager")

    f1, f2, f3, f4 = st.columns([2, 1, 1, 1])
    keyword = f1.text_input("Search Keyword", placeholder="Title, ID, participant, notes...")
    cat_filter = f2.selectbox("Category", ["All"] + CATEGORIES)
    mode_filter = f3.selectbox("Split Mode", ["All"] + SPLIT_MODES)
    status_filter = f4.selectbox("Status", ["All", "Settled", "Pending"])

    filtered = storage.search_records(
        keyword=keyword,
        category=cat_filter,
        split_mode=mode_filter,
        settlement_status=status_filter,
    )
    st.caption(f"Showing **{len(filtered)}** of **{len(records)}** records")

    for r in filtered:
        badge = "✅ Settled" if r.is_settled else f"⏳ Pending ${r.pending_amount:,.2f}"
        with st.expander(f"{r.date} | {r.title} ({r.category}) — ${r.total_amount:,.2f} [{badge}] • `{r.id}`"):
            st.write(f"**Split Mode:** {r.split_mode} | **Subtotal:** ${r.subtotal:,.2f} | **Tip:** {r.tip_percent:.1f}% (${r.tip_amount:,.2f})")
            if r.notes:
                st.caption(f"Notes: {r.notes}")

            p_cols = st.columns(len(r.participants))
            for idx, p in enumerate(r.participants):
                with p_cols[idx]:
                    st.markdown(f"**{p.name}**")
                    st.write(f"Due: **${p.total_share:,.2f}**")
                    new_paid = st.checkbox("Paid", value=p.paid, key=f"tog_{r.id}_{p.name}")
                    if new_paid != p.paid:
                        storage.toggle_participant_paid(r.id, p.name, new_paid)
                        st.rerun()

            if st.button("🗑️ Delete Bill", key=f"del_{r.id}"):
                storage.delete_record(r.id)
                st.rerun()

elif page == "📈 Analytics & Warnings":
    st.title("📈 Executive Analytics & Threshold Warning Flags")

    charts = generate_analytics_charts(records, dark_theme=True)
    c1, c2, c3 = st.columns(3)
    c1.image(str(charts["category_chart"]), use_container_width=True)
    c2.image(str(charts["trend_chart"]), use_container_width=True)
    c3.image(str(charts["settlement_chart"]), use_container_width=True)

    st.markdown("### 🚨 Automated Threshold Warning Indicators")
    if warnings:
        for w in warnings:
            sev = w["severity"]
            msg = f"**[{sev}] {w['type']}** — `{w['bill_id']}` ({w['title']}): {w['message']}"
            if sev in ("HIGH", "OVERDUE"):
                st.error(msg)
            elif sev == "ANOMALY":
                st.warning(msg)
            else:
                st.info(msg)
    else:
        st.success("All bills are within configured budget, tip, and settlement thresholds.")

elif page == "📤 Export & Bulk Import":
    st.title("📤 Multi-Format Reporting & Bulk Dataset Import")

    st.subheader("1. Generate & Download Reports")
    if st.button("Generate Executive Reports (Markdown, Audit TXT, CSV)", type="primary"):
        exported = export_all_formats(records)
        st.success("Reports generated in `exports/` directory!")
        d1, d2, d3 = st.columns(3)
        d1.download_button(
            "⬇️ Download Markdown Report (.md)",
            data=exported["markdown"].read_text(encoding="utf-8"),
            file_name=exported["markdown"].name,
            mime="text/markdown",
        )
        d2.download_button(
            "⬇️ Download Audit Log (.txt)",
            data=exported["audit_txt"].read_text(encoding="utf-8"),
            file_name=exported["audit_txt"].name,
            mime="text/plain",
        )
        d3.download_button(
            "⬇️ Download Detailed CSV (.csv)",
            data=exported["csv"].read_text(encoding="utf-8"),
            file_name=exported["csv"].name,
            mime="text/csv",
        )

    st.markdown("---")
    st.subheader("2. Bulk Legacy CSV Import (with Row-by-Row Validation Log)")
    st.caption("Upload a CSV with columns: `title, category, date, subtotal, tip_percent, split_mode, participants, values, paid, notes`")

    uploaded_csv = st.file_uploader("Upload Legacy CSV Dataset", type=["csv"])
    if uploaded_csv is not None:
        with tempfile.NamedTemporaryFile(delete=False, suffix=".csv") as tmp:
            tmp.write(uploaded_csv.getvalue())
            tmp_path = Path(tmp.name)
        imported_count, error_logs = storage.bulk_import_csv(tmp_path)
        tmp_path.unlink(missing_ok=True)
        st.success(f"Successfully imported **{imported_count}** valid bill record(s)!")
        if error_logs:
            st.warning(f"Skipped **{len(error_logs)}** malformed row(s):")
            for log in error_logs:
                st.code(log, language="text")

    if st.button("Test Import with Built-in `data/legacy_import_sample.csv`"):
        imported_count, error_logs = storage.bulk_import_csv("data/legacy_import_sample.csv")
        st.success(f"Imported **{imported_count}** valid rows from sample file.")
        if error_logs:
            st.warning("Row-by-row validation log caught the following malformed rows:")
            for log in error_logs:
                st.code(log, language="text")
