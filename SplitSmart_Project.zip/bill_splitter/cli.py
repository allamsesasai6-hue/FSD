#!/usr/bin/env python3
from __future__ import annotations
import sys
from datetime import datetime
from typing import List
from src.models import CATEGORIES, SPLIT_MODES, BillRecord
from src.validator import (
    ValidationError,
    prompt_validated,
    validate_title,
    validate_category,
    validate_date,
    validate_positive_amount,
    validate_tip_percent,
    validate_split_mode,
)
from src.engine import calculate_bill_split
from src.storage import StorageManager
from src.analytics import (
    generate_executive_summary,
    detect_threshold_warnings,
    generate_analytics_charts,
)
from src.exporter import export_all_formats
from src.seed import ensure_seeded

CYAN = "\033[96m"
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
BOLD = "\033[1m"
DIM = "\033[2m"
RESET = "\033[0m"


def print_banner() -> None:
    print(f"""{CYAN}{BOLD}
================================================================================
   ____  ____  _     ___ _____ ____  __  __    _    ____ _____ 
  / ___||  _ \| |   |_ _|_   _/ ___||  \/  |  / \  |  _ \_   _|
  \___ \| |_) | |    | |  | | \___ \| |\/| | / _ \ | |_) || |  
   ___) |  __/| |___ | |  | |  ___) | |  | |/ ___ \|  _ < | |  
  |____/|_|   |_____|___| |_| |____/|_|  |_/_/   \_\_| \_\|_|  
                                                               
  SmartCommunity Hack — Project #15: Bill Splitter (Terminal CLI)
================================================================================{RESET}""")


def print_paginated_table(records: List[BillRecord], page_size: int = 10) -> None:
    if not records:
        print(f"{YELLOW}  No matching records found.{RESET}")
        return

    total_pages = (len(records) + page_size - 1) // page_size
    page = 0
    while True:
        start = page * page_size
        chunk = records[start : start + page_size]
        print(f"\n{BOLD}{'ID':<14} {'DATE':<12} {'TITLE':<28} {'CATEGORY':<14} {'TOTAL':>10} {'STATUS':<16}{RESET}")
        print("-" * 98)
        for r in chunk:
            status = f"{GREEN}Settled{RESET}" if r.is_settled else f"{YELLOW}Pending ${r.pending_amount:.2f}{RESET}"
            title_trim = (r.title[:25] + "...") if len(r.title) > 28 else r.title
            print(f"{r.id:<14} {r.date:<12} {title_trim:<28} {r.category:<14} ${r.total_amount:>9.2f} {status}")
        print("-" * 98)
        print(f"{DIM}Showing page {page + 1} of {total_pages} ({len(records)} total records){RESET}")

        if total_pages <= 1:
            break
        nav = input("  [N]ext page | [P]revious page | [Q]uit table view: ").strip().lower()
        if nav == "n" and page + 1 < total_pages:
            page += 1
        elif nav == "p" and page > 0:
            page -= 1
        else:
            break


def handle_create_bill(storage: StorageManager) -> None:
    print(f"\n{CYAN}{BOLD}--- Record & Split a New Group Bill ---{RESET}")
    title = prompt_validated("Bill Title", validate_title)
    print(f"  Categories: {', '.join(CATEGORIES)}")
    category = prompt_validated("Category", validate_category, default="Dining")
    today = datetime.now().strftime("%Y-%m-%d")
    date_str = prompt_validated("Date (YYYY-MM-DD)", validate_date, default=today)
    subtotal = prompt_validated("Subtotal Amount ($)", lambda v: validate_positive_amount(v, "Subtotal"))
    tip_pct = prompt_validated("Tip Percentage (0-100)", validate_tip_percent, default="15")
    print(f"  Split Modes: {', '.join(SPLIT_MODES)}")
    split_mode = prompt_validated("Split Mode", validate_split_mode, default="Equal")

    while True:
        raw_names = input("Participant Names (comma-separated, e.g., Alice, Bob, Charlie): ").strip()
        names = [n.strip() for n in raw_names.split(",") if n.strip()]
        split_values = None

        try:
            if split_mode in ("Percentage", "Exact"):
                unit = "%" if split_mode == "Percentage" else "$"
                split_values = []
                for name in names:
                    val = prompt_validated(
                        f"  Enter {split_mode} share for {name} ({unit})",
                        lambda x: float(x),
                    )
                    split_values.append(val)

            notes = input("Optional Notes: ").strip()
            record = calculate_bill_split(
                title=title,
                category=category,
                date_str=date_str,
                subtotal=subtotal,
                tip_percent=tip_pct,
                split_mode=split_mode,
                participant_names=names,
                split_values=split_values,
                notes=notes,
            )
            break
        except (ValidationError, ValueError) as err:
            print(f"{RED}  [!] Split Validation Failed: {err} Please re-enter participants.{RESET}")

    storage.add_record(record)
    print(f"\n{GREEN}{BOLD}✔ Bill Saved Successfully! ID: {record.id}{RESET}")
    print(f"  Subtotal: ${record.subtotal:.2f} | Tip ({record.tip_percent}%): ${record.tip_amount:.2f} | Grand Total: ${record.total_amount:.2f}")
    print(f"  {'PARTICIPANT':<20} {'SUBTOTAL':>10} {'TIP':>10} {'TOTAL DUE':>12}")
    print("  " + "-" * 54)
    for p in record.participants:
        print(f"  {p.name:<20} ${p.subtotal_share:>9.2f} ${p.tip_share:>9.2f} ${p.total_share:>11.2f}")


def handle_search(storage: StorageManager) -> None:
    print(f"\n{CYAN}{BOLD}--- Query & Filter Stored Records ---{RESET}")
    kw = input("Keyword (title, ID, participant, or blank for all): ").strip()
    cat = input(f"Category ({'/'.join(CATEGORIES)} or All) [All]: ").strip() or "All"
    status = input("Settlement Status (All / Settled / Pending) [All]: ").strip().capitalize() or "All"
    results = storage.search_records(keyword=kw, category=cat, settlement_status=status)
    print_paginated_table(results)


def handle_settle_toggle(storage: StorageManager) -> None:
    bill_id = input("\nEnter Bill ID (e.g., BILL-XXXXXXXX): ").strip().upper()
    matches = storage.search_records(keyword=bill_id)
    if not matches:
        print(f"{RED}  [!] No bill found matching '{bill_id}'.{RESET}")
        return
    bill = matches[0]
    print(f"  Selected: {bill.title} (${bill.total_amount:.2f})")
    for idx, p in enumerate(bill.participants, 1):
        st = f"{GREEN}PAID{RESET}" if p.paid else f"{YELLOW}PENDING{RESET}"
        print(f"   {idx}. {p.name:<18} ${p.total_share:>8.2f} [{st}]")
    who = input("Enter participant name to toggle payment status: ").strip()
    if storage.toggle_participant_paid(bill.id, who):
        print(f"{GREEN}  ✔ Updated payment status for {who}.{RESET}")
    else:
        print(f"{RED}  [!] Participant '{who}' not found on this bill.{RESET}")


def handle_analytics(storage: StorageManager) -> None:
    records, _ = storage.load_all()
    summary = generate_executive_summary(records)
    warnings = detect_threshold_warnings(records)
    charts = generate_analytics_charts(records)

    print(f"\n{CYAN}{BOLD}--- Executive Summary & Financial Analytics ---{RESET}")
    print(f"  Total Bills Logged    : {summary['total_bills']}")
    print(f"  Total Volume          : ${summary['total_volume']:,.2f}")
    print(f"  Total Tips Distributed: ${summary['total_tips']:,.2f} (Avg {summary['avg_tip_pct']:.1f}%)")
    print(f"  Average Bill Size     : ${summary['avg_bill']:,.2f}")
    print(f"  Settled vs Pending    : {summary['settled_count']} Settled / {summary['pending_count']} Pending (${summary['total_pending_amount']:,.2f} owed)")
    print(f"  Top Category          : {summary['top_category']}")

    print(f"\n{BOLD}  Category Breakdown:{RESET}")
    for cat, amt in summary["category_totals"].items():
        print(f"    - {cat:<18}: ${amt:>10,.2f}")

    print(f"\n{YELLOW}{BOLD}  Threshold Warning Indicators ({len(warnings)}):{RESET}")
    if warnings:
        for w in warnings[:8]:
            print(f"    [{w['severity']}] {w['bill_id']} ({w['title']}): {w['message']}")
    else:
        print("    None — all records within healthy thresholds.")

    print(f"\n{GREEN}  ✔ Matplotlib charts generated in exports/:{RESET}")
    for k, path in charts.items():
        print(f"    -> {path}")


def handle_export(storage: StorageManager) -> None:
    records, _ = storage.load_all()
    paths = export_all_formats(records)
    print(f"\n{GREEN}{BOLD}✔ Multi-Format Reports Exported Successfully:{RESET}")
    for fmt, p in paths.items():
        print(f"  - {fmt.upper():<10}: {p}")


def handle_bulk_import(storage: StorageManager) -> None:
    path = input("\nEnter CSV path [data/legacy_import_sample.csv]: ").strip() or "data/legacy_import_sample.csv"
    count, errors = storage.bulk_import_csv(path)
    print(f"{GREEN}  ✔ Imported {count} valid bill record(s).{RESET}")
    if errors:
        print(f"{YELLOW}  [!] Row-by-Row Validation Error Log ({len(errors)} skipped):{RESET}")
        for err in errors:
            print(f"    - {err}")


def main() -> None:
    storage = StorageManager()
    _, recovery_msg = storage.load_all()
    if recovery_msg:
        print(f"{YELLOW}[RECOVERY NOTICE] {recovery_msg}{RESET}")
    if ensure_seeded(storage):
        print(f"{DIM}[INIT] Seeded 40 realistic test records into data/bills.json & data/bills.csv{RESET}")

    print_banner()
    while True:
        print(f"""
{BOLD}MAIN MENU:{RESET}
  {CYAN}1.{RESET} Split & Record a New Bill
  {CYAN}2.{RESET} View All Bills (Paginated Table)
  {CYAN}3.{RESET} Search & Filter Bills
  {CYAN}4.{RESET} Toggle Participant Settlement Status
  {CYAN}5.{RESET} Executive Summary, Warnings & Matplotlib Charts
  {CYAN}6.{RESET} Export Reports (Markdown, Audit TXT, CSV)
  {CYAN}7.{RESET} Bulk Import Legacy CSV Dataset
  {CYAN}0.{RESET} Exit
""")
        choice = input("Select an option [0-7]: ").strip()
        if choice == "1":
            handle_create_bill(storage)
        elif choice == "2":
            recs, _ = storage.load_all()
            print_paginated_table(recs)
        elif choice == "3":
            handle_search(storage)
        elif choice == "4":
            handle_settle_toggle(storage)
        elif choice == "5":
            handle_analytics(storage)
        elif choice == "6":
            handle_export(storage)
        elif choice == "7":
            handle_bulk_import(storage)
        elif choice == "0":
            print(f"{CYAN}Goodbye! All records persisted safely to JSON & CSV.{RESET}")
            sys.exit(0)
        else:
            print(f"{RED}  [!] Invalid option '{choice}'. Please enter 0–7.{RESET}")


if __name__ == "__main__":
    main()
