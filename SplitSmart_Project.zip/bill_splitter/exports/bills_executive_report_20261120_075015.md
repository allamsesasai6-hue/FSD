# SplitSmart — Executive Bill Summary Report
**Generated:** 2026-11-20 07:50:15  
**Total Records:** 40

## 1. Key Financial Metrics
| Metric | Value |
| :--- | :--- |
| Total Processed Volume | $8,542.44 |
| Total Subtotals | $7,800.13 |
| Total Tips Distributed | $742.31 |
| Average Bill Amount | $213.56 |
| Average Tip Rate | 9.78% |
| Settled Bills | 30 |
| Pending Bills | 10 ($625.25 unpaid) |
| Top Spending Category | Travel |

## 2. Category Breakdown
| Category | Total Spend |
| :--- | :--- |
| Travel | $2,643.44 |
| Dining | $1,956.00 |
| Entertainment | $1,494.37 |
| Utilities | $1,036.72 |
| Groceries | $550.47 |
| Other | $451.15 |
| Rent & Housing | $410.29 |

## 3. Threshold Warning Flags
- **[OVERDUE] Overdue Settlement** (`BILL-22E7D3A7` - Airport Uber XL Transfer #23): Bill from 2026-11-05 still has $126.11 unpaid (> 14 days).
- **[HIGH] Budget Threshold Breach** (`BILL-17B3A4D2` - Conference Group Flight Booking #27): Total bill ($725.27) exceeds threshold of $500.00.
- **[OVERDUE] Overdue Settlement** (`BILL-0ED52B1A` - Downtown Apartment Rent #36): Bill from 2026-10-21 still has $42.57 unpaid (> 14 days).
- **[OVERDUE] Overdue Settlement** (`BILL-A5787E37` - Organic Weekly Groceries #04): Bill from 2026-10-11 still has $57.44 unpaid (> 14 days).
- **[ANOMALY] High Tip Anomaly** (`BILL-687CB484` - Corporate Client Lunch #11): Tip rate of 35.0% exceeds normal ceiling (30%).
- **[INFO] Zero-Tip Dining Entry** (`BILL-53FBA486` - Quick Street Food Lunch #13): Dining bill recorded with 0% tip.
- **[OVERDUE] Overdue Settlement** (`BILL-4CE16C14` - Co-Working Day Passes #29): Bill from 2026-09-13 still has $127.23 unpaid (> 14 days).
- **[OVERDUE] Overdue Settlement** (`BILL-5226C40E` - Specialty Coffee & Brunch #22): Bill from 2026-09-07 still has $25.64 unpaid (> 14 days).
- **[OVERDUE] Overdue Settlement** (`BILL-B9DC415F` - Specialty Coffee & Brunch #07): Bill from 2026-07-24 still has $70.36 unpaid (> 14 days).
- **[HIGH] Budget Threshold Breach** (`BILL-0C1EEC39` - Conference Group Flight Booking #12): Total bill ($745.44) exceeds threshold of $500.00.
- **[OVERDUE] Overdue Settlement** (`BILL-F918C7B2` - Bulk Pantry Restock #15): Bill from 2026-07-04 still has $62.12 unpaid (> 14 days).
- **[OVERDUE] Overdue Settlement** (`BILL-C83BC37E` - Monthly Fiber Internet #02): Bill from 2026-07-03 still has $25.74 unpaid (> 14 days).
- **[OVERDUE] Overdue Settlement** (`BILL-B29979F7` - Quick Street Food Lunch #28): Bill from 2026-07-01 still has $10.51 unpaid (> 14 days).
- **[INFO] Zero-Tip Dining Entry** (`BILL-B29979F7` - Quick Street Food Lunch #28): Dining bill recorded with 0% tip.
- **[ANOMALY] High Tip Anomaly** (`BILL-131C9143` - Corporate Client Lunch #26): Tip rate of 35.0% exceeds normal ceiling (30%).
- **[OVERDUE] Overdue Settlement** (`BILL-E97DD818` - Electricity & Water Utility #09): Bill from 2026-06-23 still has $77.53 unpaid (> 14 days).

## 4. Detailed Bill Ledger
| ID | Date | Title | Category | Mode | Total | Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| BILL-22E7D3A7 | 2026-11-05 | Airport Uber XL Transfer #23 | Travel | Equal | $252.22 | Pending ($126.11) |
| BILL-17B3A4D2 | 2026-11-02 | Conference Group Flight Booking #27 | Travel | Exact | $725.27 | Settled |
| BILL-F6BC0A3D | 2026-10-23 | Organic Weekly Groceries #19 | Groceries | Exact | $87.96 | Settled |
| BILL-04F07E27 | 2026-10-22 | Team Hackathon Dinner #01 | Dining | Equal | $128.05 | Settled |
| BILL-E86E4302 | 2026-10-22 | Bulk Pantry Restock #30 | Groceries | Equal | $56.96 | Settled |
| BILL-0ED52B1A | 2026-10-21 | Downtown Apartment Rent #36 | Rent & Housing | Percentage | $219.78 | Pending ($42.57) |
| BILL-7F6536F7 | 2026-10-20 | Electricity & Water Utility #24 | Utilities | Equal | $166.93 | Settled |
| BILL-8E30B312 | 2026-10-18 | Co-Working Day Passes #14 | Other | Equal | $133.09 | Settled |
| BILL-A5787E37 | 2026-10-11 | Organic Weekly Groceries #04 | Groceries | Exact | $162.98 | Pending ($57.44) |
| BILL-687CB484 | 2026-10-10 | Corporate Client Lunch #11 | Dining | Equal | $406.90 | Settled |
| BILL-09667F75 | 2026-10-09 | Goa Weekend Villa Stay #33 | Travel | Percentage | $287.65 | Settled |
| BILL-A359C6FF | 2026-09-30 | Airport Uber XL Transfer #38 | Travel | Equal | $155.88 | Settled |
| BILL-F8F7DD48 | 2026-09-28 | Board Game Cafe Pass #25 | Entertainment | Equal | $278.48 | Settled |
| BILL-1C5CE396 | 2026-09-27 | Monthly Fiber Internet #32 | Utilities | Equal | $332.20 | Settled |
| BILL-53FBA486 | 2026-09-19 | Quick Street Food Lunch #13 | Dining | Equal | $20.31 | Settled |
| BILL-E6698786 | 2026-09-17 | Organic Weekly Groceries #34 | Groceries | Exact | $56.22 | Settled |
| BILL-4CE16C14 | 2026-09-13 | Co-Working Day Passes #29 | Other | Equal | $318.06 | Pending ($127.23) |
| BILL-5226C40E | 2026-09-07 | Specialty Coffee & Brunch #22 | Dining | Equal | $128.24 | Pending ($25.64) |
| BILL-6805342D | 2026-09-03 | Board Game Cafe Pass #40 | Entertainment | Equal | $195.63 | Settled |
| BILL-0618C78C | 2026-08-27 | Monthly Fiber Internet #17 | Utilities | Equal | $124.99 | Settled |
| BILL-889008E7 | 2026-08-19 | IMAX Sci-Fi Movie Night #05 | Entertainment | Equal | $305.05 | Settled |
| BILL-39D58663 | 2026-08-14 | Downtown Apartment Rent #06 | Rent & Housing | Percentage | $147.87 | Settled |
| BILL-0CC85697 | 2026-08-09 | Downtown Apartment Rent #21 | Rent & Housing | Percentage | $42.64 | Settled |
| BILL-4027DEB0 | 2026-08-09 | IMAX Sci-Fi Movie Night #35 | Entertainment | Equal | $261.14 | Settled |
| BILL-9D469782 | 2026-08-07 | Electricity & Water Utility #39 | Utilities | Equal | $167.29 | Settled |
| BILL-37B32840 | 2026-08-01 | Team Hackathon Dinner #31 | Dining | Equal | $365.68 | Settled |
| BILL-4C8E9349 | 2026-07-31 | Specialty Coffee & Brunch #37 | Dining | Equal | $296.02 | Settled |
| BILL-B9DC415F | 2026-07-24 | Specialty Coffee & Brunch #07 | Dining | Equal | $351.80 | Pending ($70.36) |
| BILL-1796D94D | 2026-07-23 | Board Game Cafe Pass #10 | Entertainment | Equal | $351.52 | Settled |
| BILL-0C1EEC39 | 2026-07-07 | Conference Group Flight Booking #12 | Travel | Exact | $745.44 | Settled |
| BILL-F918C7B2 | 2026-07-04 | Bulk Pantry Restock #15 | Groceries | Equal | $186.35 | Pending ($62.12) |
| BILL-A2806DB0 | 2026-07-04 | IMAX Sci-Fi Movie Night #20 | Entertainment | Equal | $102.55 | Settled |
| BILL-C83BC37E | 2026-07-03 | Monthly Fiber Internet #02 | Utilities | Equal | $51.47 | Pending ($25.74) |
| BILL-E1DF5C31 | 2026-07-01 | Team Hackathon Dinner #16 | Dining | Equal | $74.53 | Settled |
| BILL-B29979F7 | 2026-07-01 | Quick Street Food Lunch #28 | Dining | Equal | $42.02 | Pending ($10.51) |
| BILL-22EED8B2 | 2026-06-29 | Goa Weekend Villa Stay #03 | Travel | Percentage | $193.45 | Settled |
| BILL-131C9143 | 2026-06-28 | Corporate Client Lunch #26 | Dining | Equal | $142.45 | Settled |
| BILL-4BC77B61 | 2026-06-27 | Airport Uber XL Transfer #08 | Travel | Equal | $205.55 | Settled |
| BILL-FB3B82B4 | 2026-06-26 | Goa Weekend Villa Stay #18 | Travel | Percentage | $77.98 | Settled |
| BILL-E97DD818 | 2026-06-23 | Electricity & Water Utility #09 | Utilities | Equal | $193.84 | Pending ($77.53) |