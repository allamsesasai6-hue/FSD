"""SplitSmart Core Package."""
