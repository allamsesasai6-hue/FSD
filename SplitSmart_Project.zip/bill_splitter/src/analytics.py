from __future__ import annotations
from collections import defaultdict
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Any
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from src.models import BillRecord


def generate_executive_summary(records: List[BillRecord]) -> Dict[str, Any]:
    if not records:
        return {
            "total_bills": 0,
            "total_volume": 0.0,
            "total_subtotals": 0.0,
            "total_tips": 0.0,
            "avg_bill": 0.0,
            "avg_tip_pct": 0.0,
            "highest_bill": None,
            "lowest_bill": None,
            "settled_count": 0,
            "pending_count": 0,
            "total_pending_amount": 0.0,
            "top_category": "N/A",
            "category_totals": {},
            "monthly_totals": {},
            "participant_balances": {},
        }

    total_volume = round(sum(r.total_amount for r in records), 2)
    total_subtotals = round(sum(r.subtotal for r in records), 2)
    total_tips = round(sum(r.tip_amount for r in records), 2)
    avg_bill = round(total_volume / len(records), 2)
    avg_tip_pct = round(sum(r.tip_percent for r in records) / len(records), 2)

    highest_bill = max(records, key=lambda r: r.total_amount)
    lowest_bill = min(records, key=lambda r: r.total_amount)

    settled_count = sum(1 for r in records if r.is_settled)
    pending_count = len(records) - settled_count
    total_pending_amount = round(sum(r.pending_amount for r in records), 2)

    cat_totals: Dict[str, float] = defaultdict(float)
    monthly_totals: Dict[str, float] = defaultdict(float)
    participant_owed: Dict[str, float] = defaultdict(float)

    for r in records:
        cat_totals[r.category] = round(cat_totals[r.category] + r.total_amount, 2)
        month_key = r.date[:7]
        monthly_totals[month_key] = round(monthly_totals[month_key] + r.total_amount, 2)
        for p in r.participants:
            if not p.paid:
                participant_owed[p.name] = round(participant_owed[p.name] + p.total_share, 2)

    top_category = max(cat_totals.items(), key=lambda x: x[1])[0] if cat_totals else "N/A"
    sorted_months = dict(sorted(monthly_totals.items()))
    sorted_owed = dict(sorted(participant_owed.items(), key=lambda x: x[1], reverse=True))

    return {
        "total_bills": len(records),
        "total_volume": total_volume,
        "total_subtotals": total_subtotals,
        "total_tips": total_tips,
        "avg_bill": avg_bill,
        "avg_tip_pct": avg_tip_pct,
        "highest_bill": highest_bill,
        "lowest_bill": lowest_bill,
        "settled_count": settled_count,
        "pending_count": pending_count,
        "total_pending_amount": total_pending_amount,
        "top_category": top_category,
        "category_totals": dict(sorted(cat_totals.items(), key=lambda x: x[1], reverse=True)),
        "monthly_totals": sorted_months,
        "participant_balances": sorted_owed,
    }


def detect_threshold_warnings(
    records: List[BillRecord],
    high_bill_limit: float = 500.0,
    overdue_days: int = 14,
    high_tip_limit: float = 30.0,
) -> List[Dict[str, str]]:
    warnings: List[Dict[str, str]] = []
    cutoff_date = (datetime.now() - timedelta(days=overdue_days)).strftime("%Y-%m-%d")

    for r in records:
        if r.total_amount > high_bill_limit:
            warnings.append(
                {
                    "severity": "HIGH",
                    "type": "Budget Threshold Breach",
                    "bill_id": r.id,
                    "title": r.title,
                    "message": f"Total bill (${r.total_amount:,.2f}) exceeds threshold of ${high_bill_limit:,.2f}.",
                }
            )
        if not r.is_settled and r.date < cutoff_date:
            warnings.append(
                {
                    "severity": "OVERDUE",
                    "type": "Overdue Settlement",
                    "bill_id": r.id,
                    "title": r.title,
                    "message": f"Bill from {r.date} still has ${r.pending_amount:,.2f} unpaid (> {overdue_days} days).",
                }
            )
        if r.tip_percent > high_tip_limit:
            warnings.append(
                {
                    "severity": "ANOMALY",
                    "type": "High Tip Anomaly",
                    "bill_id": r.id,
                    "title": r.title,
                    "message": f"Tip rate of {r.tip_percent:.1f}% exceeds normal ceiling ({high_tip_limit:.0f}%).",
                }
            )
        elif r.tip_percent == 0 and r.category == "Dining":
            warnings.append(
                {
                    "severity": "INFO",
                    "type": "Zero-Tip Dining Entry",
                    "bill_id": r.id,
                    "title": r.title,
                    "message": "Dining bill recorded with 0% tip.",
                }
            )

    return warnings


def generate_analytics_charts(
    records: List[BillRecord],
    output_dir: Path = Path("exports"),
    dark_theme: bool = True,
) -> Dict[str, Path]:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    summary = generate_executive_summary(records)

    bg_color = "#0E1117" if dark_theme else "#FFFFFF"
    card_color = "#161B22" if dark_theme else "#F8FAFC"
    text_color = "#F0F6FC" if dark_theme else "#1E293B"
    grid_color = "#30363D" if dark_theme else "#E2E8F0"
    palette = ["#00D4AA", "#3B82F6", "#8B5CF6", "#F59E0B", "#EC4899", "#10B981", "#64748B"]

    saved_charts: Dict[str, Path] = {}

    cat_path = output_dir / "category_breakdown.png"
    fig, ax = plt.subplots(figsize=(7, 4.2), dpi=150)
    fig.patch.set_facecolor(bg_color)
    ax.set_facecolor(card_color)
    cats = list(summary["category_totals"].keys())
    vals = list(summary["category_totals"].values())
    if cats:
        bars = ax.barh(cats[::-1], vals[::-1], color=palette[: len(cats)][::-1], height=0.58)
        ax.set_xlabel("Total Spend ($)", color=text_color, fontsize=10)
        ax.set_title("Spending Breakdown by Category", color=text_color, fontsize=12, fontweight="bold", pad=12)
        ax.tick_params(colors=text_color, labelsize=9)
        ax.grid(axis="x", linestyle="--", alpha=0.4, color=grid_color)
        for spine in ["top", "right"]:
            ax.spines[spine].set_visible(False)
        for spine in ["bottom", "left"]:
            ax.spines[spine].set_color(grid_color)
        for bar in bars:
            w = bar.get_width()
            ax.text(w + max(vals) * 0.015, bar.get_y() + bar.get_height() / 2, f"${w:,.0f}", va="center", color=text_color, fontsize=8.5)
    plt.tight_layout()
    plt.savefig(cat_path, facecolor=bg_color)
    plt.close(fig)
    saved_charts["category_chart"] = cat_path

    trend_path = output_dir / "monthly_trend.png"
    fig, ax = plt.subplots(figsize=(7, 4.2), dpi=150)
    fig.patch.set_facecolor(bg_color)
    ax.set_facecolor(card_color)
    months = list(summary["monthly_totals"].keys())
    m_vals = list(summary["monthly_totals"].values())
    if months:
        ax.plot(months, m_vals, marker="o", linewidth=2.5, markersize=7, color="#00D4AA")
        ax.fill_between(months, m_vals, color="#00D4AA", alpha=0.18)
        ax.set_ylabel("Total Spend ($)", color=text_color, fontsize=10)
        ax.set_title("Monthly Expense Trend", color=text_color, fontsize=12, fontweight="bold", pad=12)
        ax.tick_params(colors=text_color, labelsize=9)
        plt.xticks(rotation=30)
        ax.grid(True, linestyle="--", alpha=0.4, color=grid_color)
        for spine in ["top", "right"]:
            ax.spines[spine].set_visible(False)
        for spine in ["bottom", "left"]:
            ax.spines[spine].set_color(grid_color)
    plt.tight_layout()
    plt.savefig(trend_path, facecolor=bg_color)
    plt.close(fig)
    saved_charts["trend_chart"] = trend_path

    settle_path = output_dir / "settlement_status.png"
    fig, ax = plt.subplots(figsize=(6, 4.2), dpi=150)
    fig.patch.set_facecolor(bg_color)
    ax.set_facecolor(card_color)
    paid_total = round(summary["total_volume"] - summary["total_pending_amount"], 2)
    pending_total = summary["total_pending_amount"]
    if summary["total_volume"] > 0:
        wedges, texts, autotexts = ax.pie(
            [paid_total, pending_total],
            labels=[f"Settled (${paid_total:,.2f})", f"Pending (${pending_total:,.2f})"],
            autopct="%1.1f%%",
            startangle=140,
            colors=["#00D4AA", "#F59E0B"],
            wedgeprops={"width": 0.45, "edgecolor": bg_color, "linewidth": 2},
            textprops={"color": text_color, "fontsize": 9.5},
        )
        for at in autotexts:
            at.set_color("#0E1117")
            at.set_fontweight("bold")
        ax.set_title("Collection & Settlement Ratio", color=text_color, fontsize=12, fontweight="bold", pad=12)
    plt.tight_layout()
    plt.savefig(settle_path, facecolor=bg_color)
    plt.close(fig)
    saved_charts["settlement_chart"] = settle_path

    return saved_charts
