from __future__ import annotations
from typing import List, Optional
from src.models import BillRecord, ParticipantShare
from src.validator import (
    validate_title,
    validate_category,
    validate_date,
    validate_positive_amount,
    validate_tip_percent,
    validate_split_mode,
    validate_participants,
)


def calculate_bill_split(
    title: str,
    category: str,
    date_str: str,
    subtotal: float,
    tip_percent: float,
    split_mode: str,
    participant_names: List[str],
    split_values: Optional[List[float]] = None,
    paid_flags: Optional[List[bool]] = None,
    notes: str = "",
) -> BillRecord:
    """
    Core Business Logic Engine:
    Validates inputs, calculates subtotal & proportional tip shares, and reconciles
    any penny rounding discrepancies so participant totals sum strictly to total_amount.
    """
    clean_title = validate_title(title)
    clean_category = validate_category(category)
    clean_date = validate_date(date_str)
    clean_subtotal = validate_positive_amount(subtotal, "Subtotal")
    clean_tip_pct = validate_tip_percent(tip_percent)
    clean_mode = validate_split_mode(split_mode)
    clean_names, clean_vals = validate_participants(
        participant_names, clean_mode, split_values, clean_subtotal
    )

    tip_amount = round(clean_subtotal * (clean_tip_pct / 100.0), 2)
    total_amount = round(clean_subtotal + tip_amount, 2)
    n = len(clean_names)

    if clean_mode == "Equal":
        raw_subtotals = [clean_subtotal / n for _ in range(n)]
    elif clean_mode == "Percentage":
        raw_subtotals = [clean_subtotal * (pct / 100.0) for pct in clean_vals]
    else:
        raw_subtotals = list(clean_vals)

    rounded_subtotals = [round(x, 2) for x in raw_subtotals]
    sub_diff = round(clean_subtotal - sum(rounded_subtotals), 2)
    if sub_diff != 0 and n > 0:
        max_idx = max(range(n), key=lambda i: rounded_subtotals[i])
        rounded_subtotals[max_idx] = round(rounded_subtotals[max_idx] + sub_diff, 2)

    if clean_subtotal > 0 and tip_amount > 0:
        raw_tips = [tip_amount * (sub / clean_subtotal) for sub in rounded_subtotals]
    else:
        raw_tips = [0.0 for _ in range(n)]

    rounded_tips = [round(t, 2) for t in raw_tips]
    tip_diff = round(tip_amount - sum(rounded_tips), 2)
    if tip_diff != 0 and n > 0:
        max_idx = max(range(n), key=lambda i: rounded_subtotals[i])
        rounded_tips[max_idx] = round(rounded_tips[max_idx] + tip_diff, 2)

    participants: List[ParticipantShare] = []
    for idx, name in enumerate(clean_names):
        sub_s = rounded_subtotals[idx]
        tip_s = rounded_tips[idx]
        tot_s = round(sub_s + tip_s, 2)
        is_paid = bool(paid_flags[idx]) if (paid_flags and idx < len(paid_flags)) else False
        participants.append(
            ParticipantShare(
                name=name,
                input_value=clean_vals[idx],
                subtotal_share=sub_s,
                tip_share=tip_s,
                total_share=tot_s,
                paid=is_paid,
            )
        )

    return BillRecord(
        title=clean_title,
        category=clean_category,
        date=clean_date,
        subtotal=clean_subtotal,
        tip_percent=clean_tip_pct,
        tip_amount=tip_amount,
        total_amount=total_amount,
        split_mode=clean_mode,
        participants=participants,
        notes=str(notes or "").strip(),
    )
