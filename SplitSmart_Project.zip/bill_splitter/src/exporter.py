from __future__ import annotations
import csv
from datetime import datetime
from pathlib import Path
from typing import Dict, List
from src.models import BillRecord
from src.analytics import generate_executive_summary, detect_threshold_warnings


def export_all_formats(records: List[BillRecord], export_dir: Path = Path("exports")) -> Dict[str, Path]:
    export_dir = Path(export_dir)
    export_dir.mkdir(parents=True, exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")

    summary = generate_executive_summary(records)
    warnings = detect_threshold_warnings(records)

    md_path = export_dir / f"bills_executive_report_{ts}.md"
    lines = [
        "# SplitSmart — Executive Bill Summary Report",
        f"**Generated:** {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}  ",
        f"**Total Records:** {summary['total_bills']}",
        "",
        "## 1. Key Financial Metrics",
        "| Metric | Value |",
        "| :--- | :--- |",
        f"| Total Processed Volume | ${summary['total_volume']:,.2f} |",
        f"| Total Subtotals | ${summary['total_subtotals']:,.2f} |",
        f"| Total Tips Distributed | ${summary['total_tips']:,.2f} |",
        f"| Average Bill Amount | ${summary['avg_bill']:,.2f} |",
        f"| Average Tip Rate | {summary['avg_tip_pct']:.2f}% |",
        f"| Settled Bills | {summary['settled_count']} |",
        f"| Pending Bills | {summary['pending_count']} (${summary['total_pending_amount']:,.2f} unpaid) |",
        f"| Top Spending Category | {summary['top_category']} |",
        "",
        "## 2. Category Breakdown",
        "| Category | Total Spend |",
        "| :--- | :--- |",
    ]
    for cat, amt in summary["category_totals"].items():
        lines.append(f"| {cat} | ${amt:,.2f} |")

    lines.extend(["", "## 3. Threshold Warning Flags"])
    if warnings:
        for w in warnings:
            lines.append(f"- **[{w['severity']}] {w['type']}** (`{w['bill_id']}` - {w['title']}): {w['message']}")
    else:
        lines.append("- No threshold breaches or overdue anomalies detected.")

    lines.extend([
        "",
        "## 4. Detailed Bill Ledger",
        "| ID | Date | Title | Category | Mode | Total | Status |",
        "| :--- | :--- | :--- | :--- | :--- | :--- | :--- |",
    ])
    for r in records:
        status = "Settled" if r.is_settled else f"Pending (${r.pending_amount:,.2f})"
        lines.append(f"| {r.id} | {r.date} | {r.title} | {r.category} | {r.split_mode} | ${r.total_amount:,.2f} | {status} |")

    md_path.write_text("\n".join(lines), encoding="utf-8")

    txt_path = export_dir / f"bills_audit_log_{ts}.txt"
    audit_lines = [
        "=" * 78,
        "SPLITSMART AUDIT LOG & PARTICIPANT LEDGER",
        f"Timestamp: {datetime.now().isoformat(timespec='seconds')}",
        "=" * 78,
        f"TOTAL BILLS: {summary['total_bills']} | TOTAL VOLUME: ${summary['total_volume']:,.2f} | PENDING: ${summary['total_pending_amount']:,.2f}",
        "-" * 78,
    ]
    for r in records:
        audit_lines.append(
            f"[{r.id}] {r.date} | {r.title} ({r.category}) | Subtotal: ${r.subtotal:.2f} | Tip: {r.tip_percent:.1f}% (${r.tip_amount:.2f}) | Total: ${r.total_amount:.2f}"
        )
        for p in r.participants:
            state = "PAID" if p.paid else "OWES"
            audit_lines.append(
                f"    -> {p.name:<18} | Share: ${p.subtotal_share:>8.2f} + Tip: ${p.tip_share:>6.2f} = ${p.total_share:>8.2f} [{state}]"
            )
        audit_lines.append("-" * 78)
    txt_path.write_text("\n".join(audit_lines), encoding="utf-8")

    csv_path = export_dir / f"bills_detailed_export_{ts}.csv"
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerow([
            "Bill_ID", "Date", "Title", "Category", "Split_Mode",
            "Bill_Subtotal", "Tip_Percent", "Bill_Total",
            "Participant", "Subtotal_Share", "Tip_Share", "Total_Share", "Payment_Status"
        ])
        for r in records:
            for p in r.participants:
                writer.writerow([
                    r.id, r.date, r.title, r.category, r.split_mode,
                    f"{r.subtotal:.2f}", f"{r.tip_percent:.2f}", f"{r.total_amount:.2f}",
                    p.name, f"{p.subtotal_share:.2f}", f"{p.tip_share:.2f}", f"{p.total_share:.2f}",
                    "Settled" if p.paid else "Pending"
                ])

    return {
        "markdown": md_path,
        "audit_txt": txt_path,
        "csv": csv_path,
    }
