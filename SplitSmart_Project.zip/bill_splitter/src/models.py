from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import List, Dict, Any
import uuid
from datetime import datetime

CATEGORIES = [
    "Dining",
    "Utilities",
    "Travel",
    "Groceries",
    "Entertainment",
    "Rent & Housing",
    "Other",
]

SPLIT_MODES = ["Equal", "Exact", "Percentage"]


@dataclass
class ParticipantShare:
    name: str
    input_value: float = 0.0
    subtotal_share: float = 0.0
    tip_share: float = 0.0
    total_share: float = 0.0
    paid: bool = False

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ParticipantShare":
        return cls(
            name=str(data.get("name", "Unknown")),
            input_value=float(data.get("input_value", 0.0)),
            subtotal_share=float(data.get("subtotal_share", 0.0)),
            tip_share=float(data.get("tip_share", 0.0)),
            total_share=float(data.get("total_share", 0.0)),
            paid=bool(data.get("paid", False)),
        )


@dataclass
class BillRecord:
    title: str
    category: str
    date: str
    subtotal: float
    tip_percent: float
    tip_amount: float
    total_amount: float
    split_mode: str
    participants: List[ParticipantShare] = field(default_factory=list)
    notes: str = ""
    id: str = field(default_factory=lambda: f"BILL-{uuid.uuid4().hex[:8].upper()}")
    created_at: str = field(default_factory=lambda: datetime.now().isoformat(timespec="seconds"))

    @property
    def is_settled(self) -> bool:
        return len(self.participants) > 0 and all(p.paid for p in self.participants)

    @property
    def pending_amount(self) -> float:
        return round(sum(p.total_share for p in self.participants if not p.paid), 2)

    @property
    def paid_amount(self) -> float:
        return round(sum(p.total_share for p in self.participants if p.paid), 2)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "id": self.id,
            "title": self.title,
            "category": self.category,
            "date": self.date,
            "subtotal": round(self.subtotal, 2),
            "tip_percent": round(self.tip_percent, 2),
            "tip_amount": round(self.tip_amount, 2),
            "total_amount": round(self.total_amount, 2),
            "split_mode": self.split_mode,
            "participants": [p.to_dict() for p in self.participants],
            "notes": self.notes,
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "BillRecord":
        required = {"title", "category", "date", "subtotal", "tip_percent", "total_amount", "split_mode", "participants"}
        if not required.issubset(data.keys()):
            missing = required - set(data.keys())
            raise ValueError(f"Schema validation failed; missing fields: {missing}")

        participants = [ParticipantShare.from_dict(p) for p in data["participants"]]
        return cls(
            id=str(data.get("id", f"BILL-{uuid.uuid4().hex[:8].upper()}")),
            title=str(data["title"]),
            category=str(data["category"]),
            date=str(data["date"]),
            subtotal=float(data["subtotal"]),
            tip_percent=float(data["tip_percent"]),
            tip_amount=float(data.get("tip_amount", round(float(data["total_amount"]) - float(data["subtotal"]), 2))),
            total_amount=float(data["total_amount"]),
            split_mode=str(data["split_mode"]),
            participants=participants,
            notes=str(data.get("notes", "")),
            created_at=str(data.get("created_at", datetime.now().isoformat(timespec="seconds"))),
        )
