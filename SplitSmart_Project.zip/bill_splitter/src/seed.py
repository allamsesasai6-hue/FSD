from __future__ import annotations
import csv
import random
from datetime import datetime, timedelta
from pathlib import Path
from typing import List
from src.engine import calculate_bill_split
from src.models import BillRecord
from src.storage import StorageManager

SAMPLE_PEOPLE = ["Aarav", "Priya", "Rohan", "Ananya", "Vikram", "Sneha", "Kabir", "Meera", "Dev", "Ishita"]

SCENARIOS = [
    ("Team Hackathon Dinner", "Dining", "Equal", 18.0, "Celebration dinner after prototype sprint"),
    ("Monthly Fiber Internet", "Utilities", "Equal", 0.0, "1 Gbps symmetrical broadband bill"),
    ("Goa Weekend Villa Stay", "Travel", "Percentage", 10.0, "Master bedroom split at 40%"),
    ("Organic Weekly Groceries", "Groceries", "Exact", 5.0, "Itemized supermarket receipt"),
    ("IMAX Sci-Fi Movie Night", "Entertainment", "Equal", 12.0, "Tickets + gourmet popcorn combo"),
    ("Downtown Apartment Rent", "Rent & Housing", "Percentage", 0.0, "Monthly lease split by room size"),
    ("Specialty Coffee & Brunch", "Dining", "Equal", 20.0, "Sunday morning cafe meetup"),
    ("Airport Uber XL Transfer", "Travel", "Equal", 15.0, "Early morning terminal drop"),
    ("Electricity & Water Utility", "Utilities", "Equal", 0.0, "Summer AC peak billing cycle"),
    ("Board Game Cafe Pass", "Entertainment", "Equal", 15.0, "4-hour table pass and snacks"),
    ("Corporate Client Lunch", "Dining", "Equal", 35.0, "High tip anomaly test case"),
    ("Conference Group Flight Booking", "Travel", "Exact", 0.0, "High-value budget threshold test case"),
    ("Quick Street Food Lunch", "Dining", "Equal", 0.0, "Zero-tip dining boundary test case"),
    ("Co-Working Day Passes", "Other", "Equal", 10.0, "Hot desk booking for 3 founders"),
    ("Bulk Pantry Restock", "Groceries", "Equal", 8.0, "Costco wholesale run"),
]


def generate_seed_records(count: int = 40) -> List[BillRecord]:
    rng = random.Random(42)
    records: List[BillRecord] = []
    base_date = datetime.now()

    for i in range(count):
        title_base, category, mode, tip_pct, note = SCENARIOS[i % len(SCENARIOS)]
        title = f"{title_base} #{i + 1:02d}"
        days_ago = rng.randint(1, 150)
        date_str = (base_date - timedelta(days=days_ago)).strftime("%Y-%m-%d")

        num_people = rng.randint(2, 5)
        people = rng.sample(SAMPLE_PEOPLE, num_people)

        if "High-value" in note:
            subtotal = round(rng.uniform(550.0, 950.0), 2)
        elif "Quick Street Food" in title_base:
            subtotal = round(rng.uniform(18.0, 45.0), 2)
        else:
            subtotal = round(rng.uniform(42.0, 340.0), 2)

        split_vals = None
        if mode == "Percentage":
            raw_weights = [rng.randint(15, 45) for _ in range(num_people)]
            total_w = sum(raw_weights)
            pcts = [round((w / total_w) * 100, 2) for w in raw_weights]
            pcts[-1] = round(100.0 - sum(pcts[:-1]), 2)
            split_vals = pcts
        elif mode == "Exact":
            raw_parts = [round(subtotal / num_people + rng.uniform(-5, 5), 2) for _ in range(num_people)]
            raw_parts[-1] = round(subtotal - sum(raw_parts[:-1]), 2)
            if any(x <= 0 for x in raw_parts):
                mode = "Equal"
                split_vals = None
            else:
                split_vals = raw_parts

        paid_flags = [
            True if (days_ago > 25 and rng.random() > 0.2) else (rng.random() > 0.45)
            for _ in range(num_people)
        ]

        rec = calculate_bill_split(
            title=title,
            category=category,
            date_str=date_str,
            subtotal=subtotal,
            tip_percent=tip_pct,
            split_mode=mode,
            participant_names=people,
            split_values=split_vals,
            paid_flags=paid_flags,
            notes=note,
        )
        records.append(rec)

    records.sort(key=lambda r: r.date, reverse=True)
    return records


def create_legacy_sample_csv(path: Path = Path("data/legacy_import_sample.csv")) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    rows = [
        ["title", "category", "date", "subtotal", "tip_percent", "split_mode", "participants", "values", "paid", "notes"],
        ["Legacy Startup Pizza Night", "Dining", "2026-10-15", "84.50", "15", "Equal", "Aarav|Priya|Rohan", "", "false", "Valid legacy import row 1"],
        ["Legacy Cloud Server Bill", "Utilities", "2026-10-20", "120.00", "0", "Percentage", "Vikram|Sneha", "60|40", "true", "Valid legacy import row 2"],
        ["Broken Negative Bill", "Dining", "2026-10-22", "-45.00", "10", "Equal", "Aarav|Bob", "", "false", "Intentional invalid subtotal"],
        ["Broken Date Format Bill", "Travel", "22/10/2026", "200.00", "10", "Equal", "Aarav|Bob", "", "false", "Intentional invalid date"],
        ["Broken Percentage Sum", "Groceries", "2026-10-25", "90.00", "5", "Percentage", "Priya|Meera", "50|30", "false", "Intentional 80% sum error"],
    ]
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        writer.writerows(rows)
    return path


def ensure_seeded(storage: StorageManager) -> bool:
    records, _ = storage.load_all()
    create_legacy_sample_csv()
    if not records:
        seeded = generate_seed_records(40)
        storage.save_all(seeded)
        return True
    return False
