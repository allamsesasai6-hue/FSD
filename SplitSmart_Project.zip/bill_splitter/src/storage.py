from __future__ import annotations
import csv
import json
import shutil
from datetime import datetime
from pathlib import Path
from typing import List, Optional, Tuple
from src.models import BillRecord
from src.engine import calculate_bill_split
from src.validator import ValidationError

DEFAULT_JSON_PATH = Path("data/bills.json")
DEFAULT_CSV_PATH = Path("data/bills.csv")


class StorageManager:
    def __init__(self, json_path: Path = DEFAULT_JSON_PATH, csv_path: Path = DEFAULT_CSV_PATH):
        self.json_path = Path(json_path)
        self.csv_path = Path(csv_path)
        self.json_path.parent.mkdir(parents=True, exist_ok=True)
        self.csv_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_initialized()

    def _ensure_initialized(self) -> None:
        if not self.json_path.exists():
            self._write_json([])
        if not self.csv_path.exists():
            self._write_csv([])

    def _write_json(self, records: List[BillRecord]) -> None:
        payload = {
            "schema_version": "1.0",
            "updated_at": datetime.now().isoformat(timespec="seconds"),
            "records": [r.to_dict() for r in records],
        }
        with open(self.json_path, "w", encoding="utf-8") as f:
            json.dump(payload, f, indent=2)

    def _write_csv(self, records: List[BillRecord]) -> None:
        headers = [
            "id",
            "title",
            "category",
            "date",
            "subtotal",
            "tip_percent",
            "tip_amount",
            "total_amount",
            "split_mode",
            "participant_count",
            "participants_summary",
            "is_settled",
            "pending_amount",
            "notes",
        ]
        with open(self.csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=headers)
            writer.writeheader()
            for r in records:
                summary = "; ".join(
                    f"{p.name}:{p.total_share:.2f}({'Paid' if p.paid else 'Pending'})"
                    for p in r.participants
                )
                writer.writerow(
                    {
                        "id": r.id,
                        "title": r.title,
                        "category": r.category,
                        "date": r.date,
                        "subtotal": f"{r.subtotal:.2f}",
                        "tip_percent": f"{r.tip_percent:.2f}",
                        "tip_amount": f"{r.tip_amount:.2f}",
                        "total_amount": f"{r.total_amount:.2f}",
                        "split_mode": r.split_mode,
                        "participant_count": len(r.participants),
                        "participants_summary": summary,
                        "is_settled": r.is_settled,
                        "pending_amount": f"{r.pending_amount:.2f}",
                        "notes": r.notes,
                    }
                )

    def save_all(self, records: List[BillRecord]) -> None:
        self._write_json(records)
        self._write_csv(records)

    def load_all(self) -> Tuple[List[BillRecord], Optional[str]]:
        if not self.json_path.exists():
            self._ensure_initialized()
            return [], None

        try:
            with open(self.json_path, "r", encoding="utf-8") as f:
                raw = json.load(f)
            raw_records = raw.get("records", raw) if isinstance(raw, dict) else raw
            if not isinstance(raw_records, list):
                raise ValueError("Root JSON structure is not a list or valid schema dict.")
            records = [BillRecord.from_dict(item) for item in raw_records]
            return records, None
        except (json.JSONDecodeError, ValueError, KeyError, TypeError) as exc:
            backup_name = f"{self.json_path.stem}_corrupt_{datetime.now().strftime('%Y%m%d_%H%M%S')}.bak"
            backup_path = self.json_path.with_name(backup_name)
            shutil.copy2(self.json_path, backup_path)
            self._write_json([])
            self._write_csv([])
            msg = f"Corrupted storage detected ({exc}). Backed up to {backup_path.name} and initialized clean database."
            return [], msg

    def add_record(self, record: BillRecord) -> None:
        records, _ = self.load_all()
        records.insert(0, record)
        self.save_all(records)

    def delete_record(self, bill_id: str) -> bool:
        records, _ = self.load_all()
        updated = [r for r in records if r.id != bill_id]
        if len(updated) == len(records):
            return False
        self.save_all(updated)
        return True

    def toggle_participant_paid(self, bill_id: str, participant_name: str, paid_status: Optional[bool] = None) -> bool:
        records, _ = self.load_all()
        changed = False
        for r in records:
            if r.id == bill_id:
                for p in r.participants:
                    if p.name.lower() == participant_name.lower():
                        p.paid = (not p.paid) if paid_status is None else bool(paid_status)
                        changed = True
                        break
        if changed:
            self.save_all(records)
        return changed

    def search_records(
        self,
        keyword: str = "",
        category: str = "All",
        split_mode: str = "All",
        settlement_status: str = "All",
        date_from: Optional[str] = None,
        date_to: Optional[str] = None,
    ) -> List[BillRecord]:
        records, _ = self.load_all()
        kw = keyword.strip().lower()
        results: List[BillRecord] = []

        for r in records:
            if category and category != "All" and r.category.lower() != category.lower():
                continue
            if split_mode and split_mode != "All" and r.split_mode.lower() != split_mode.lower():
                continue
            if settlement_status == "Settled" and not r.is_settled:
                continue
            if settlement_status == "Pending" and r.is_settled:
                continue
            if date_from and r.date < date_from:
                continue
            if date_to and r.date > date_to:
                continue
            if kw:
                in_title = kw in r.title.lower()
                in_id = kw in r.id.lower()
                in_notes = kw in r.notes.lower()
                in_participants = any(kw in p.name.lower() for p in r.participants)
                if not (in_title or in_id or in_notes or in_participants):
                    continue
            results.append(r)

        return results

    def bulk_import_csv(self, csv_file_path: Path | str) -> Tuple[int, List[str]]:
        path = Path(csv_file_path)
        if not path.exists():
            return 0, [f"File not found: {path}"]

        imported_records: List[BillRecord] = []
        error_logs: List[str] = []

        with open(path, "r", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for row_idx, row in enumerate(reader, start=2):
                try:
                    raw_names = [n.strip() for n in str(row.get("participants", "")).split("|") if n.strip()]
                    raw_vals_str = str(row.get("values", "")).strip()
                    split_vals = (
                        [float(x.strip()) for x in raw_vals_str.split("|") if x.strip()]
                        if raw_vals_str
                        else None
                    )
                    paid_str = str(row.get("paid", "")).strip().lower()
                    paid_flags = [paid_str in ("true", "1", "yes", "settled")] * len(raw_names)

                    rec = calculate_bill_split(
                        title=row.get("title", ""),
                        category=row.get("category", "Other"),
                        date_str=row.get("date", ""),
                        subtotal=row.get("subtotal", 0),
                        tip_percent=row.get("tip_percent", 0),
                        split_mode=row.get("split_mode", "Equal"),
                        participant_names=raw_names,
                        split_values=split_vals,
                        paid_flags=paid_flags,
                        notes=row.get("notes", "Imported via Bulk CSV"),
                    )
                    imported_records.append(rec)
                except (ValidationError, ValueError, TypeError) as err:
                    error_logs.append(f"Row {row_idx} ('{row.get('title', 'N/A')}'): {err}")

        if imported_records:
            existing, _ = self.load_all()
            self.save_all(imported_records + existing)

        return len(imported_records), error_logs
