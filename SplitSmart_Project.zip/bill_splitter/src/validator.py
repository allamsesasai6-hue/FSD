from __future__ import annotations
import re
from datetime import datetime
from typing import List, Tuple, Optional
from src.models import CATEGORIES, SPLIT_MODES


class ValidationError(Exception):
    """Raised when user input violates domain constraints."""


DATE_REGEX = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def validate_title(title: str) -> str:
    cleaned = str(title or "").strip()
    if len(cleaned) < 2:
        raise ValidationError("Bill title must be at least 2 characters long.")
    if len(cleaned) > 100:
        raise ValidationError("Bill title must not exceed 100 characters.")
    return cleaned


def validate_category(category: str) -> str:
    cleaned = str(category or "").strip()
    for cat in CATEGORIES:
        if cat.lower() == cleaned.lower():
            return cat
    raise ValidationError(f"Invalid category '{category}'. Choose from: {', '.join(CATEGORIES)}.")


def validate_date(date_str: str) -> str:
    cleaned = str(date_str or "").strip()
    if not DATE_REGEX.match(cleaned):
        raise ValidationError("Date must follow YYYY-MM-DD format (e.g., 2026-11-20).")
    try:
        datetime.strptime(cleaned, "%Y-%m-%d")
    except ValueError as exc:
        raise ValidationError(f"Invalid calendar date: {cleaned}") from exc
    return cleaned


def validate_positive_amount(value: float | str, field_name: str = "Amount", max_val: float = 1_000_000.0) -> float:
    try:
        num = float(value)
    except (TypeError, ValueError) as exc:
        raise ValidationError(f"{field_name} must be a valid number.") from exc
    if num <= 0:
        raise ValidationError(f"{field_name} must be greater than 0.")
    if num > max_val:
        raise ValidationError(f"{field_name} cannot exceed {max_val:,.2f}.")
    return round(num, 2)


def validate_tip_percent(value: float | str) -> float:
    try:
        num = float(value)
    except (TypeError, ValueError) as exc:
        raise ValidationError("Tip percentage must be a valid number.") from exc
    if num < 0 or num > 100:
        raise ValidationError("Tip percentage must be between 0% and 100%.")
    return round(num, 2)


def validate_split_mode(mode: str) -> str:
    cleaned = str(mode or "").strip()
    for m in SPLIT_MODES:
        if m.lower() == cleaned.lower():
            return m
    raise ValidationError(f"Invalid split mode '{mode}'. Choose from: {', '.join(SPLIT_MODES)}.")


def validate_participants(
    names: List[str],
    split_mode: str,
    values: Optional[List[float]] = None,
    subtotal: Optional[float] = None,
) -> Tuple[List[str], List[float]]:
    if not names or len(names) < 1:
        raise ValidationError("At least 1 participant is required.")
    if len(names) > 100:
        raise ValidationError("Maximum 100 participants supported per bill.")

    cleaned_names: List[str] = []
    seen = set()
    for raw in names:
        name = str(raw or "").strip()
        if not name:
            raise ValidationError("Participant names cannot be blank.")
        if len(name) > 40:
            raise ValidationError(f"Participant name '{name}' exceeds 40 characters.")
        key = name.lower()
        if key in seen:
            raise ValidationError(f"Duplicate participant name detected: '{name}'.")
        seen.add(key)
        cleaned_names.append(name)

    mode = validate_split_mode(split_mode)
    if mode == "Equal":
        return cleaned_names, [1.0] * len(cleaned_names)

    if values is None or len(values) != len(cleaned_names):
        raise ValidationError(f"{mode} split requires a numeric value for every participant.")

    parsed_vals: List[float] = []
    for idx, v in enumerate(values):
        try:
            fv = float(v)
        except (TypeError, ValueError) as exc:
            raise ValidationError(f"Invalid numeric value for {cleaned_names[idx]}.") from exc
        if fv < 0:
            raise ValidationError(f"Share value for {cleaned_names[idx]} cannot be negative.")
        parsed_vals.append(round(fv, 2))

    if mode == "Percentage":
        total_pct = round(sum(parsed_vals), 2)
        if abs(total_pct - 100.0) > 0.05:
            raise ValidationError(f"Percentages must sum to 100% (currently {total_pct:.2f}%).")
    elif mode == "Exact":
        if subtotal is None:
            raise ValidationError("Subtotal is required to validate Exact split amounts.")
        total_exact = round(sum(parsed_vals), 2)
        if abs(total_exact - round(subtotal, 2)) > 0.02:
            raise ValidationError(
                f"Exact participant amounts ({total_exact:.2f}) must equal subtotal ({subtotal:.2f})."
            )

    return cleaned_names, parsed_vals


def prompt_validated(prompt_text: str, validator_fn, default: Optional[str] = None):
    while True:
        suffix = f" [{default}]" if default is not None else ""
        raw = input(f"{prompt_text}{suffix}: ").strip()
        if not raw and default is not None:
            raw = default
        try:
            return validator_fn(raw)
        except ValidationError as err:
            print(f"  [!] Validation Error: {err} Please try again.")
