from pathlib import Path
import pytest
from src.engine import calculate_bill_split
from src.validator import ValidationError
from src.storage import StorageManager
from src.analytics import generate_executive_summary, detect_threshold_warnings
from src.seed import generate_seed_records, create_legacy_sample_csv


def test_equal_split_with_penny_reconciliation():
    bill = calculate_bill_split(
        title="Three Way Coffee",
        category="Dining",
        date_str="2026-11-20",
        subtotal=100.00,
        tip_percent=0.0,
        split_mode="Equal",
        participant_names=["Alice", "Bob", "Charlie"],
    )
    assert bill.total_amount == 100.00
    assert round(sum(p.total_share for p in bill.participants), 2) == 100.00


def test_percentage_and_exact_splits():
    pct_bill = calculate_bill_split(
        title="Apartment Rent",
        category="Rent & Housing",
        date_str="2026-11-01",
        subtotal=1000.00,
        tip_percent=0.0,
        split_mode="Percentage",
        participant_names=["Aarav", "Priya"],
        split_values=[60.0, 40.0],
    )
    assert pct_bill.participants[0].total_share == 600.00
    assert pct_bill.participants[1].total_share == 400.00

    exact_bill = calculate_bill_split(
        title="Grocery Run",
        category="Groceries",
        date_str="2026-11-05",
        subtotal=80.00,
        tip_percent=10.0,
        split_mode="Exact",
        participant_names=["Rohan", "Sneha"],
        split_values=[50.0, 30.0],
    )
    assert exact_bill.tip_amount == 8.00
    assert exact_bill.total_amount == 88.00
    assert exact_bill.participants[0].total_share == 55.00
    assert exact_bill.participants[1].total_share == 33.00


def test_defensive_validation_errors():
    with pytest.raises(ValidationError):
        calculate_bill_split("Bad", "Dining", "2026-11-20", -50, 10, "Equal", ["A", "B"])
    with pytest.raises(ValidationError):
        calculate_bill_split("Bad Date", "Dining", "20-11-2026", 50, 10, "Equal", ["A", "B"])
    with pytest.raises(ValidationError):
        calculate_bill_split("Dupes", "Dining", "2026-11-20", 50, 10, "Equal", ["Alice", "alice"])
    with pytest.raises(ValidationError):
        calculate_bill_split("Bad Pct", "Dining", "2026-11-20", 50, 10, "Percentage", ["A", "B"], [50, 40])


def test_storage_persistence_and_corruption_recovery(tmp_path: Path):
    j_path = tmp_path / "bills.json"
    c_path = tmp_path / "bills.csv"
    sm = StorageManager(json_path=j_path, csv_path=c_path)

    bill = calculate_bill_split("Dinner", "Dining", "2026-11-20", 120.0, 15.0, "Equal", ["Aarav", "Priya"])
    sm.add_record(bill)
    loaded, warn = sm.load_all()
    assert warn is None
    assert len(loaded) == 1
    assert loaded[0].id == bill.id

    j_path.write_text("{corrupt_json:::", encoding="utf-8")
    recovered, warn_msg = sm.load_all()
    assert warn_msg is not None
    assert recovered == []


def test_bulk_import_and_analytics(tmp_path: Path):
    sm = StorageManager(json_path=tmp_path / "bills.json", csv_path=tmp_path / "bills.csv")
    sample_csv = create_legacy_sample_csv(tmp_path / "legacy.csv")
    imported, errors = sm.bulk_import_csv(sample_csv)
    assert imported == 2
    assert len(errors) == 3

    seeds = generate_seed_records(40)
    summary = generate_executive_summary(seeds)
    assert summary["total_bills"] == 40
    warnings = detect_threshold_warnings(seeds)
    assert len(warnings) > 0
